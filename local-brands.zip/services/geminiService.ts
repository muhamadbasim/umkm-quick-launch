import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

// Initialize the client
// NOTE: In a real production app, API keys should be handled via a backend proxy to prevent exposure.
// For this PRD prototype, we use the env variable directly as instructed.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeImageForLandingPage = async (base64Image: string, language: 'en' | 'id' = 'en'): Promise<AIAnalysisResult> => {
  const modelId = "gemini-2.5-flash"; // Optimized for speed and cost as per PRD

  // Clean the base64 string if it contains the data URL prefix
  const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");

  const langInstruction = language === 'id' ? 'Bahasa Indonesia' : 'English';

  const prompt = `
    You are an expert brand strategist and copywriter for high-end local brands.
    Analyze this image of a product or service.
    Create compelling, sophisticated copy for a modern landing page.
    
    Return a JSON object with:
    1. businessNameSuggestion: A modern, premium name for the business (if not obvious).
    2. headline: A sophisticated, punchy hook (max 8 words) in ${langInstruction}.
    3. story: A 2-sentence emotional brand story (${langInstruction}) that elevates the perceived value.
    4. suggestedTemplate: One of ["culinary", "fashion", "service"] based on the image content.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg", // Assuming JPEG for simplicity in this demo
              data: cleanBase64,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            businessNameSuggestion: { type: Type.STRING },
            headline: { type: Type.STRING },
            story: { type: Type.STRING },
            suggestedTemplate: { type: Type.STRING, enum: ["culinary", "fashion", "service"] },
          },
          required: ["businessNameSuggestion", "headline", "story", "suggestedTemplate"],
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as AIAnalysisResult;
    } else {
      throw new Error("No response text from Gemini");
    }
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    // Fallback data in case of error (graceful degradation)
    const isId = language === 'id';
    return {
      businessNameSuggestion: "Luxe Local",
      headline: isId ? "Keunggulan dalam Setiap Detail" : "Excellence in Every Detail",
      story: isId 
        ? "Dibuat dengan kualitas tanpa kompromi, produk kami mendefinisikan ulang standar kemewahan lokal untuk pelanggan yang cerdas."
        : "Crafted with uncompromising quality, our products redefine local luxury standards for the discerning customer.",
      suggestedTemplate: "service",
    };
  }
};