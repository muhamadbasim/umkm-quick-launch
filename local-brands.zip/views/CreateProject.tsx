import React, { useState, useRef, useEffect } from 'react';
import { Project, WizardStep, AIAnalysisResult } from '../types';
import { analyzeImageForLandingPage } from '../services/geminiService';
import { Button } from '../components/Button';
import { TemplatePreview } from '../components/TemplatePreview';
import { useLanguage } from '../contexts/LanguageContext';

interface CreateProjectProps {
  initialProject?: Project;
  onSuccess: (project: Project) => void;
  onCancel: () => void;
}

const CreateProject: React.FC<CreateProjectProps> = ({ initialProject, onSuccess, onCancel }) => {
  const { t, language } = useLanguage();
  const [step, setStep] = useState<WizardStep>('upload');
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [editedData, setEditedData] = useState<AIAnalysisResult | null>(null);
  
  // Publishing State
  const [publishStatus, setPublishStatus] = useState<'idle' | 'generating' | 'pushing' | 'deploying' | 'completed'>('idle');
  const [finalProject, setFinalProject] = useState<Project | null>(null);

  // History State for Undo/Redo
  const [history, setHistory] = useState<AIAnalysisResult[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // -- Initialize for Editing --
  useEffect(() => {
    if (initialProject) {
        setImage(initialProject.imageUrl);
        setPhoneNumber(initialProject.phone);
        
        const initialData: AIAnalysisResult = {
            businessNameSuggestion: initialProject.businessName,
            headline: initialProject.headline,
            story: initialProject.story,
            suggestedTemplate: initialProject.templateId
        };
        
        setAnalysis(initialData); 
        setEditedData(initialData);
        setHistory([initialData]);
        setHistoryIndex(0);
        
        // Jump straight to review step
        setStep('review');
    }
  }, [initialProject]);

  // -- Step 1: Handle Image Upload --
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // -- Step 2: Trigger AI Analysis --
  const handleAnalyze = async () => {
    if (!image) return;
    setStep('analyzing');
    
    try {
      // Pass the current language to the AI service
      const result = await analyzeImageForLandingPage(image, language);
      setAnalysis(result);
      setEditedData(result);
      
      // Initialize History
      setHistory([result]);
      setHistoryIndex(0);
      
      setStep('review');
    } catch (error) {
      alert(t.createProject.failedAnalyze);
      setStep('upload');
    }
  };

  // -- Undo/Redo Logic --
  const addToHistory = (newData: AIAnalysisResult) => {
    if (historyIndex === -1) return;
    
    // Simple deep compare to avoid duplicate history entries
    if (JSON.stringify(history[historyIndex]) === JSON.stringify(newData)) return;

    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newData);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setEditedData(history[newIndex]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setEditedData(history[newIndex]);
    }
  };

  // -- Step 3: Publish Simulation --
  const handlePublish = () => {
    if (!editedData || !image) return;
    
    setStep('publishing');
    setPublishStatus('generating');

    // Simulate Step 1: Generating Code
    setTimeout(() => {
        setPublishStatus('pushing');
        
        // Simulate Step 2: Pushing to GitHub
        setTimeout(() => {
            setPublishStatus('deploying');

            // Simulate Step 3: Deploying
            setTimeout(() => {
                setPublishStatus('completed');

                // Create Project Object
                const newProject: Project = {
                    // If editing, keep the original ID, otherwise generate new
                    id: initialProject ? initialProject.id : Date.now().toString(),
                    businessName: editedData.businessNameSuggestion,
                    imageUrl: image,
                    headline: editedData.headline,
                    story: editedData.story,
                    phone: phoneNumber,
                    templateId: editedData.suggestedTemplate,
                    status: 'published',
                    publishedUrl: initialProject?.publishedUrl || `https://${editedData.businessNameSuggestion.toLowerCase().replace(/[^a-z0-9]/g, '-')}.github.io`,
                    createdAt: initialProject ? initialProject.createdAt : Date.now(),
                };
                
                setFinalProject(newProject);
                // NOTE: We no longer call onSuccess automatically. We wait for user action.
            }, 3000); 
        }, 2500);
    }, 2000);
  };

  // -- Render Helper: Progress Bar --
  const renderProgressBar = () => {
    const steps = ['upload', 'analyzing', 'review', 'publishing'];
    const currentIndex = steps.indexOf(step);
    const progress = Math.max(5, ((currentIndex + 1) / steps.length) * 100);

    return (
      <div className="w-full bg-gray-200 dark:bg-gray-700 h-1.5 mb-6">
        <div 
          className="bg-indigo-600 h-1.5 transition-all duration-500 ease-out" 
          style={{ width: `${progress}%` }}
        />
      </div>
    );
  };

  // ------------------------------------
  // VIEW: Upload
  // ------------------------------------
  if (step === 'upload') {
    return (
      <div className="flex flex-col h-full bg-white dark:bg-gray-800 transition-colors">
        {renderProgressBar()}
        <div className="flex-1 p-6 flex flex-col items-center justify-center">
          <div className="w-full max-w-sm">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 text-center">{t.createProject.uploadTitle}</h2>
            <p className="text-gray-500 dark:text-gray-400 text-center mb-8">
              {t.createProject.uploadSubtitle}
            </p>

            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-indigo-200 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl aspect-[4/3] flex flex-col items-center justify-center cursor-pointer hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors mb-6 relative overflow-hidden group"
            >
              {image ? (
                <>
                  <img src={image} alt="Preview" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-white font-medium">{t.createProject.changePhoto}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 rounded-full bg-indigo-100 dark:bg-indigo-800 text-indigo-600 dark:text-indigo-300 flex items-center justify-center mb-3">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <span className="font-semibold text-indigo-900 dark:text-indigo-200">{t.createProject.tapToTake}</span>
                </>
              )}
            </div>

            <input 
              type="file" 
              accept="image/*" 
              ref={fileInputRef} 
              className="hidden" 
              onChange={handleFileChange}
            />

            <div className="flex gap-3">
               <Button variant="outline" fullWidth onClick={onCancel}>{t.createProject.cancelBtn}</Button>
               <Button 
                  fullWidth 
                  onClick={handleAnalyze} 
                  disabled={!image}
                  variant="primary"
                >
                  {t.createProject.analyzeBtn}
               </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ------------------------------------
  // VIEW: Analyzing
  // ------------------------------------
  if (step === 'analyzing') {
    return (
      <div className="flex flex-col h-full bg-white dark:bg-gray-800 items-center justify-center p-8 text-center transition-colors">
        <div className="relative w-24 h-24 mb-6">
          <div className="absolute inset-0 border-4 border-indigo-100 dark:border-indigo-900 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
             <svg className="w-8 h-8 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
             </svg>
          </div>
        </div>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{t.createProject.analyzingTitle}</h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm max-w-xs animate-pulse whitespace-pre-line">
          {t.createProject.analyzingSteps}
        </p>
      </div>
    );
  }

  // ------------------------------------
  // VIEW: Review & Edit
  // ------------------------------------
  if (step === 'review' && editedData) {
    return (
      <div className="flex flex-col h-full bg-gray-50 dark:bg-gray-900 transition-colors">
        {renderProgressBar()}
        
        {/* Main Editor Layout - Responsive Grid on Desktop */}
        <div className="flex-1 overflow-y-auto lg:overflow-hidden p-4 pb-32 lg:pb-4">
          <div className="max-w-6xl mx-auto w-full lg:flex lg:gap-8 lg:h-[calc(100vh-140px)]">
            
            {/* LEFT COLUMN: Editor Tools */}
            <div className="flex-1 space-y-4 lg:overflow-y-auto lg:pr-2 lg:h-full scrollbar-thin">
              
              {/* Content Editor */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-5 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center">
                    <span className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300 flex items-center justify-center text-xs mr-2">✓</span>
                    {t.createProject.editContent}
                  </h2>
                  <div className="flex gap-1 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                    <button 
                      onClick={handleUndo} 
                      disabled={historyIndex <= 0} 
                      className="p-1.5 rounded-md hover:bg-white dark:hover:bg-gray-600 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600 dark:text-gray-300 transition-all shadow-sm disabled:shadow-none"
                      title="Undo"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6M3 10l6-6" /></svg>
                    </button>
                    <button 
                      onClick={handleRedo} 
                      disabled={historyIndex >= history.length - 1} 
                      className="p-1.5 rounded-md hover:bg-white dark:hover:bg-gray-600 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600 dark:text-gray-300 transition-all shadow-sm disabled:shadow-none"
                      title="Redo"
                    >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 10h-10a8 8 0 00-8 8v2M21 10l-6 6M21 10l-6-6" /></svg>
                    </button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1">{t.createProject.businessName}</label>
                    <input 
                      type="text" 
                      value={editedData.businessNameSuggestion}
                      onChange={(e) => setEditedData({...editedData, businessNameSuggestion: e.target.value})}
                      onBlur={() => addToHistory(editedData)}
                      className="w-full p-3 border border-gray-200 dark:border-gray-700 dark:bg-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-semibold text-gray-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1">{t.createProject.headline}</label>
                    <input 
                      type="text" 
                      value={editedData.headline}
                      onChange={(e) => setEditedData({...editedData, headline: e.target.value})}
                      onBlur={() => addToHistory(editedData)}
                      className="w-full p-3 border border-gray-200 dark:border-gray-700 dark:bg-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1">{t.createProject.story}</label>
                    <textarea 
                      value={editedData.story}
                      rows={4}
                      onChange={(e) => setEditedData({...editedData, story: e.target.value})}
                      onBlur={() => addToHistory(editedData)}
                      className="w-full p-3 border border-gray-200 dark:border-gray-700 dark:bg-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none resize-none text-gray-900 dark:text-white"
                    />
                  </div>

                   <div>
                    <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-1">{t.createProject.whatsapp}</label>
                    <input 
                      type="tel" 
                      placeholder="e.g. 628123456789"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g,''))}
                      className="w-full p-3 border border-gray-200 dark:border-gray-700 dark:bg-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-gray-900 dark:text-white"
                    />
                    <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-1">{t.createProject.whatsappHint}</p>
                  </div>
                </div>
              </div>

              {/* Template Selector */}
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4 transition-all">
                <label className="block text-xs font-bold text-gray-500 dark:text-gray-400 uppercase mb-3">{t.createProject.designStyle}</label>
                <div className="grid grid-cols-3 gap-3">
                  {['culinary', 'fashion', 'service'].map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        const newData = {...editedData, suggestedTemplate: t as any};
                        setEditedData(newData);
                        addToHistory(newData);
                      }}
                      className={`py-3 px-2 text-xs font-medium rounded-xl border-2 capitalize transition-all duration-200 flex flex-col items-center justify-center gap-1 ${
                        editedData.suggestedTemplate === t 
                          ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-300 border-indigo-600 dark:border-indigo-400 transform scale-105' 
                          : 'bg-white dark:bg-gray-700 text-gray-500 dark:text-gray-400 border-gray-100 dark:border-gray-600 hover:border-gray-200 dark:hover:border-gray-500'
                      }`}
                    >
                      <span className={`block w-8 h-8 rounded-full mb-1 flex items-center justify-center text-lg ${
                          editedData.suggestedTemplate === t ? 'bg-indigo-600 text-white shadow-md' : 'bg-gray-100 dark:bg-gray-600'
                      }`}>
                        {t === 'culinary' && '🍳'}
                        {t === 'fashion' && '👗'}
                        {t === 'service' && '🛠️'}
                      </span>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: Live Preview */}
            <div className="mt-6 lg:mt-0 lg:flex-1 lg:h-full flex flex-col">
               <div className="bg-gray-100 dark:bg-gray-900/50 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 flex flex-col items-center justify-center relative overflow-hidden lg:h-full transition-colors">
                  <div className="absolute top-4 left-0 right-0 text-center z-10 pointer-events-none">
                     <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest bg-white/50 dark:bg-black/20 px-3 py-1 rounded-full backdrop-blur-sm">{t.createProject.livePreview}</span>
                  </div>
                  
                  {image && (
                    <TemplatePreview 
                      template={editedData.suggestedTemplate} 
                      data={editedData} 
                      image={image}
                      className="w-full max-w-[320px] shadow-2xl transition-all duration-500" 
                    />
                  )}
                  
                  <p className="text-xs text-gray-400 mt-6 text-center max-w-xs animate-pulse hidden lg:block">
                    {t.createProject.updatesInstantly}
                  </p>
               </div>
            </div>

          </div>
        </div>

        {/* Footer Actions */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 lg:static lg:bg-transparent lg:border-t-0 z-30 transition-all">
           <div className="max-w-md mx-auto lg:max-w-6xl lg:flex lg:justify-end">
               <div className="lg:w-1/3">
                   <Button 
                    fullWidth 
                    onClick={handlePublish}
                    disabled={!phoneNumber}
                    variant={phoneNumber ? 'primary' : 'outline'}
                    className="lg:py-4 lg:text-lg shadow-xl shadow-indigo-200/50 dark:shadow-none transition-all hover:scale-[1.02]"
                   >
                    {phoneNumber ? t.createProject.launchBtn : t.createProject.enterWhatsappBtn}
                   </Button>
               </div>
           </div>
        </div>
      </div>
    );
  }

  // ------------------------------------
  // VIEW: Publishing
  // ------------------------------------
  if (step === 'publishing') {
    // Determine progress based on status
    let progressPercentage = 5;
    if (publishStatus === 'generating') progressPercentage = 20;
    if (publishStatus === 'pushing') progressPercentage = 50;
    if (publishStatus === 'deploying') progressPercentage = 80;
    if (publishStatus === 'completed') progressPercentage = 100;

    const stepsList = ['generating', 'pushing', 'deploying', 'completed'];
    const currentStepIndex = stepsList.indexOf(publishStatus);

    return (
      <div className="flex flex-col h-full bg-white dark:bg-gray-800 items-center justify-center p-8 transition-colors">
        <div className="w-full max-w-md">
            <div className="text-center mb-10">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {publishStatus === 'completed' ? t.createProject.successTitle : t.createProject.launchingTitle}
                </h3>
                <p className="text-gray-500 dark:text-gray-400">
                    {publishStatus === 'completed' 
                        ? t.createProject.successSubtitle
                        : t.createProject.launchingSubtitle}
                </p>
            </div>

            <div className="space-y-8 relative pl-2">
                {/* Vertical Line */}
                <div className="absolute left-6 top-4 bottom-4 w-0.5 bg-gray-100 dark:bg-gray-700 -z-10"></div>

                {/* Step 1 */}
                <div className="flex items-center gap-4 group">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-500 z-10 ${
                        publishStatus === 'generating' 
                        ? 'bg-white dark:bg-gray-800 border-indigo-600 text-indigo-600 scale-110 shadow-lg shadow-indigo-200/50' 
                        : currentStepIndex > 0
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-400'
                    }`}>
                        {currentStepIndex > 0 ? (
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                        ) : (
                             <span className="text-sm font-bold">1</span>
                        )}
                    </div>
                    <div className="flex-1">
                         <h4 className={`font-bold text-lg ${publishStatus === 'generating' ? 'text-indigo-600 dark:text-indigo-400' : currentStepIndex > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400 dark:text-gray-600'}`}>{t.createProject.step1}</h4>
                         {publishStatus === 'generating' && <p className="text-sm text-gray-500 animate-pulse mt-0.5">{t.createProject.step1Desc}</p>}
                    </div>
                </div>

                {/* Step 2 */}
                <div className="flex items-center gap-4 group">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-500 z-10 ${
                        publishStatus === 'pushing' 
                        ? 'bg-white dark:bg-gray-800 border-indigo-600 text-indigo-600 scale-110 shadow-lg shadow-indigo-200/50' 
                        : currentStepIndex > 1
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-400'
                    }`}>
                         {currentStepIndex > 1 ? (
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                        ) : (
                             <span className="text-sm font-bold">2</span>
                        )}
                    </div>
                    <div className="flex-1">
                         <h4 className={`font-bold text-lg ${publishStatus === 'pushing' ? 'text-indigo-600 dark:text-indigo-400' : currentStepIndex > 1 ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400 dark:text-gray-600'}`}>{t.createProject.step2}</h4>
                         {publishStatus === 'pushing' && <p className="text-sm text-gray-500 animate-pulse mt-0.5">{t.createProject.step2Desc}</p>}
                    </div>
                </div>

                {/* Step 3 */}
                 <div className="flex items-center gap-4 group">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-500 z-10 ${
                        publishStatus === 'deploying' 
                        ? 'bg-white dark:bg-gray-800 border-indigo-600 text-indigo-600 scale-110 shadow-lg shadow-indigo-200/50' 
                        : currentStepIndex > 2
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-400'
                    }`}>
                        {currentStepIndex > 2 ? (
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                        ) : (
                             <span className="text-sm font-bold">3</span>
                        )}
                    </div>
                    <div className="flex-1">
                         <h4 className={`font-bold text-lg ${publishStatus === 'deploying' ? 'text-indigo-600 dark:text-indigo-400' : currentStepIndex > 2 ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-400 dark:text-gray-600'}`}>{t.createProject.step3}</h4>
                         {publishStatus === 'deploying' && <p className="text-sm text-gray-500 animate-pulse mt-0.5">{t.createProject.step3Desc}</p>}
                    </div>
                </div>
            </div>
            
             {/* Progress Bar overall */}
             <div className="w-full bg-gray-100 dark:bg-gray-700 h-2.5 rounded-full overflow-hidden mt-12 mb-8">
                 <div 
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 h-full transition-all duration-1000 ease-linear shadow-[0_0_10px_rgba(79,70,229,0.5)]" 
                    style={{ width: `${progressPercentage}%` }}
                 ></div>
             </div>

             {/* Success Actions */}
             {publishStatus === 'completed' && finalProject && (
                 <div className="animate-[fade-in-up_0.5s_ease-out] w-full max-w-sm mx-auto">
                    <Button 
                        fullWidth 
                        onClick={() => onSuccess(finalProject)}
                        variant="primary"
                        className="shadow-xl mb-4"
                    >
                        {t.createProject.backDashboard}
                    </Button>
                    {finalProject.publishedUrl && (
                        <a 
                            href={finalProject.publishedUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center justify-center text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors group"
                        >
                            {t.createProject.viewSite}
                            <svg className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </a>
                    )}
                 </div>
             )}

        </div>
      </div>
    );
  }

  return null;
};

export default CreateProject;